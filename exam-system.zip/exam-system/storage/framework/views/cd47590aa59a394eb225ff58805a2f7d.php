<?php $__env->startSection('title', 'Exam Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8">
    <div class="max-w-7xl mx-auto">
        <!-- Header -->
        <div class="flex justify-between items-center mb-6">
            <div>
                <h1 class="text-3xl font-bold text-gray-800"><?php echo e($exam->title); ?></h1>
                <p class="text-gray-600 mt-1">Exam Code: <span class="font-mono"><?php echo e($exam->exam_code); ?></span></p>
            </div>
            <div class="flex gap-3">
                <a href="<?php echo e(route('teacher.exams.index')); ?>" 
                    class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded">
                    ← Back to Exams
                </a>
                <?php if($status === 'Scheduled'): ?>
                    <a href="<?php echo e(route('teacher.exams.edit', $exam->id)); ?>" 
                        class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                        Edit Exam
                    </a>
                <?php endif; ?>
            </div>
        </div>

        <!-- Success/Error Messages -->
        <?php if(session('success')): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <!-- Status Badge -->
        <div class="mb-6">
            <?php
                if ($status === 'Scheduled') {
                    $statusColor = 'bg-yellow-100 text-yellow-800 border-yellow-300';
                } elseif ($status === 'Ongoing') {
                    $statusColor = 'bg-green-100 text-green-800 border-green-300';
                } else {
                    $statusColor = 'bg-gray-100 text-gray-800 border-gray-300';
                }
            ?>
            <span class="inline-flex items-center px-4 py-2 rounded-full text-sm font-semibold border <?php echo e($statusColor); ?>">
                <span class="w-2 h-2 mr-2 rounded-full <?php echo e($status === 'Ongoing' ? 'bg-green-500 animate-pulse' : 'bg-current'); ?>"></span>
                <?php echo e($status); ?>

            </span>
        </div>

        <!-- Statistics Cards -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm font-medium">Total Questions</p>
                        <p class="text-3xl font-bold text-gray-800 mt-1"><?php echo e($statistics['total_questions']); ?></p>
                    </div>
                    <div class="bg-blue-100 rounded-full p-3">
                        <svg class="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm font-medium">Total Attempts</p>
                        <p class="text-3xl font-bold text-gray-800 mt-1"><?php echo e($statistics['total_attempts']); ?></p>
                    </div>
                    <div class="bg-purple-100 rounded-full p-3">
                        <svg class="w-8 h-8 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path>
                        </svg>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm font-medium">Completed</p>
                        <p class="text-3xl font-bold text-gray-800 mt-1"><?php echo e($statistics['completed_attempts']); ?></p>
                    </div>
                    <div class="bg-green-100 rounded-full p-3">
                        <svg class="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm font-medium">Average Score</p>
                        <p class="text-3xl font-bold text-gray-800 mt-1"><?php echo e(number_format($statistics['average_score'], 1)); ?>%</p>
                    </div>
                    <div class="bg-yellow-100 rounded-full p-3">
                        <svg class="w-8 h-8 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"></path>
                        </svg>
                    </div>
                </div>
            </div>
        </div>

        <!-- Exam Details -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            <!-- Main Details -->
            <div class="lg:col-span-2 bg-white rounded-lg shadow p-6">
                <h2 class="text-xl font-bold text-gray-800 mb-4">Exam Information</h2>
                
                <div class="space-y-4">
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <p class="text-sm font-medium text-gray-500">Category</p>
                            <p class="text-gray-800 font-medium"><?php echo e($exam->examCategory->name); ?></p>
                        </div>
                        <div>
                            <p class="text-sm font-medium text-gray-500">Duration</p>
                            <p class="text-gray-800 font-medium"><?php echo e($exam->duration_minutes); ?> minutes</p>
                        </div>
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <p class="text-sm font-medium text-gray-500">Total Questions</p>
                            <p class="text-gray-800 font-medium"><?php echo e($exam->total_questions); ?></p>
                        </div>
                        <div>
                            <p class="text-sm font-medium text-gray-500">Total Marks</p>
                            <p class="text-gray-800 font-medium"><?php echo e($exam->total_marks); ?></p>
                        </div>
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <p class="text-sm font-medium text-gray-500">Start Time</p>
                            <p class="text-gray-800 font-medium"><?php echo e($exam->start_time->format('d M Y, h:i A')); ?></p>
                        </div>
                        <div>
                            <p class="text-sm font-medium text-gray-500">End Time</p>
                            <p class="text-gray-800 font-medium"><?php echo e($exam->end_time->format('d M Y, h:i A')); ?></p>
                        </div>
                    </div>

                    <?php if($exam->description): ?>
                        <div>
                            <p class="text-sm font-medium text-gray-500 mb-1">Description</p>
                            <p class="text-gray-800"><?php echo e($exam->description); ?></p>
                        </div>
                    <?php endif; ?>

                    <div>
                        <p class="text-sm font-medium text-gray-500 mb-2">Settings</p>
                        <div class="flex flex-wrap gap-2">
                            <?php if($exam->show_results_immediately): ?>
                                <span class="px-3 py-1 bg-blue-100 text-blue-800 text-sm rounded-full">Show Results Immediately</span>
                            <?php endif; ?>
                            <?php if($exam->randomize_questions): ?>
                                <span class="px-3 py-1 bg-purple-100 text-purple-800 text-sm rounded-full">Randomize Questions</span>
                            <?php endif; ?>
                            <?php if($exam->randomize_options): ?>
                                <span class="px-3 py-1 bg-green-100 text-green-800 text-sm rounded-full">Randomize Options</span>
                            <?php endif; ?>
                            <?php if($exam->allow_resume): ?>
                                <span class="px-3 py-1 bg-yellow-100 text-yellow-800 text-sm rounded-full">Allow Resume</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Marking Schemes -->
            <div class="bg-white rounded-lg shadow p-6">
                <h2 class="text-xl font-bold text-gray-800 mb-4">Marking Schemes</h2>
                
                <div class="space-y-3">
                    <?php $__currentLoopData = $exam->markingSchemes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scheme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="border rounded-lg p-3">
                            <p class="font-medium text-gray-800 mb-2"><?php echo e($scheme->subject->name); ?></p>
                            <div class="text-sm space-y-1">
                                <p class="text-gray-600">✓ Correct: <span class="font-medium text-green-600">+<?php echo e($scheme->correct_marks); ?></span></p>
                                <p class="text-gray-600">✗ Wrong: <span class="font-medium text-red-600">-<?php echo e($scheme->wrong_marks); ?></span></p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

        <!-- Questions List -->
        <div class="bg-white rounded-lg shadow p-6 mb-8">
            <h2 class="text-xl font-bold text-gray-800 mb-4">Questions (<?php echo e($exam->questions->count()); ?>)</h2>
            
            <div class="space-y-4">
                <?php $__currentLoopData = $exam->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="border rounded-lg p-4 hover:bg-gray-50">
                        <div class="flex items-start justify-between">
                            <div class="flex-1">
                                <div class="flex items-center gap-2 mb-2">
                                    <span class="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded">Q<?php echo e($index + 1); ?></span>
                                    <span class="text-xs text-gray-500"><?php echo e($question->subject->name ?? 'N/A'); ?></span>
                                </div>
                                <p class="text-gray-800 font-medium mb-2"><?php echo e($question->question_text); ?></p>
                                
                                <?php if($question->options && $question->options->count() > 0): ?>
                                    <div class="mt-2 space-y-1">
                                        <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="flex items-center text-sm <?php echo e($option->is_correct ? 'text-green-600 font-medium' : 'text-gray-600'); ?>">
                                                <span class="mr-2"><?php echo e($option->is_correct ? '✓' : '○'); ?></span>
                                                <span><?php echo e($option->option_text); ?></span>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <!-- Recent Attempts -->
        <?php if($exam->attempts->count() > 0): ?>
            <div class="bg-white rounded-lg shadow p-6">
                <h2 class="text-xl font-bold text-gray-800 mb-4">Recent Attempts</h2>
                
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Student</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Started At</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Score</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php $__currentLoopData = $exam->attempts->take(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attempt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm font-medium text-gray-900"><?php echo e($attempt->student->user->name ?? 'N/A'); ?></div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php echo e($attempt->started_at ? $attempt->started_at->format('d M Y, h:i A') : 'N/A'); ?>

                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php
                                            $statusColors = [
                                                'in_progress' => 'bg-yellow-100 text-yellow-800',
                                                'submitted' => 'bg-green-100 text-green-800',
                                                'auto_submitted' => 'bg-blue-100 text-blue-800',
                                            ];
                                        ?>
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo e($statusColors[$attempt->status] ?? 'bg-gray-100 text-gray-800'); ?>">
                                            <?php echo e(ucfirst(str_replace('_', ' ', $attempt->status))); ?>

                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php echo e($attempt->score ? number_format($attempt->score, 1) . '%' : '-'); ?>

                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <a href="#" class="text-blue-600 hover:text-blue-900">View Details</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>

        <!-- Delete Button -->
        <?php if($status === 'Scheduled' && $exam->attempts->count() === 0): ?>
            <div class="mt-8 border-t pt-6">
                <form action="<?php echo e(route('teacher.exams.destroy', $exam->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this exam? This action cannot be undone.');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                        Delete Exam
                    </button>
                </form>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\exam\exam-system\resources\views/teacher/exams/show.blade.php ENDPATH**/ ?>