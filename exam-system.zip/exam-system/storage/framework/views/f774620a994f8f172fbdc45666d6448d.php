<?php $__env->startSection('title', 'Exams - Admin'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8">
    <div class="flex justify-between items-center mb-8">
        <h1 class="text-3xl font-bold text-gray-900">Exam Management</h1>
        <a href="<?php echo e(route('admin.exams.create')); ?>" class="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-6 rounded-lg transition">
            ➕ Create New Exam
        </a>
    </div>

    <!-- Filters -->
    <div class="bg-white rounded-lg shadow-md p-6 mb-6">
        <form method="GET" action="<?php echo e(route('admin.exams.index')); ?>" class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Category</label>
                <select name="category_id" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500">
                    <option value="">All Categories</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" <?php echo e(request('category_id') == $category->id ? 'selected' : ''); ?>>
                            <?php echo e($category->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Status</label>
                <select name="status" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500">
                    <option value="">All Status</option>
                    <option value="upcoming" <?php echo e(request('status') == 'upcoming' ? 'selected' : ''); ?>>Upcoming</option>
                    <option value="ongoing" <?php echo e(request('status') == 'ongoing' ? 'selected' : ''); ?>>Ongoing</option>
                    <option value="expired" <?php echo e(request('status') == 'expired' ? 'selected' : ''); ?>>Expired</option>
                </select>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Search</label>
                <div class="flex gap-2">
                    <input type="text" name="search" value="<?php echo e(request('search')); ?>" 
                           placeholder="Search exam title..."
                           class="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500">
                    <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition">
                        🔍
                    </button>
                </div>
            </div>
        </form>
    </div>

    <!-- Exams Grid -->
    <?php if($exams->count() > 0): ?>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
            <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white rounded-lg shadow-md hover:shadow-lg transition overflow-hidden">
                    <div class="p-6">
                        <div class="flex justify-between items-start mb-3">
                            <h3 class="text-lg font-bold text-gray-900"><?php echo e($exam->title); ?></h3>
                            <span class="px-3 py-1 text-xs font-semibold rounded-full 
                                <?php if($exam->status === 'ongoing'): ?> bg-green-100 text-green-800
                                <?php elseif($exam->status === 'upcoming'): ?> bg-blue-100 text-blue-800
                                <?php else: ?> bg-gray-100 text-gray-800
                                <?php endif; ?>">
                                <?php echo e(ucfirst($exam->status)); ?>

                            </span>
                        </div>
                        
                        <p class="text-sm text-gray-600 mb-3"><?php echo e($exam->examCategory->name); ?></p>
                        
                        <div class="space-y-2 text-sm text-gray-700 mb-4">
                            <div class="flex items-center">
                                <span class="w-24 text-gray-500">Code:</span>
                                <span class="font-mono font-semibold"><?php echo e($exam->exam_code); ?></span>
                            </div>
                            <div class="flex items-center">
                                <span class="w-24 text-gray-500">Duration:</span>
                                <span><?php echo e($exam->duration_minutes); ?> minutes</span>
                            </div>
                            <div class="flex items-center">
                                <span class="w-24 text-gray-500">Questions:</span>
                                <span><?php echo e($exam->questions->count()); ?></span>
                            </div>
                            <div class="flex items-center">
                                <span class="w-24 text-gray-500">Total Marks:</span>
                                <span><?php echo e($exam->total_marks); ?></span>
                            </div>
                            <div class="flex items-center">
                                <span class="w-24 text-gray-500">Start Time:</span>
                                <span><?php echo e($exam->start_time->format('d M Y, h:i A')); ?></span>
                            </div>
                        </div>

                        <div class="flex gap-2">
                            <a href="<?php echo e(route('admin.exams.show', $exam)); ?>" 
                               class="flex-1 text-center bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg transition">
                                View Details
                            </a>
                            <a href="<?php echo e(route('admin.exams.edit', $exam)); ?>" 
                               class="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition">
                                ✏️
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Pagination -->
        <div class="bg-white rounded-lg shadow-md p-4">
            <?php echo e($exams->links()); ?>

        </div>
    <?php else: ?>
        <div class="bg-white rounded-lg shadow-md p-12 text-center">
            <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
            </svg>
            <h3 class="mt-2 text-sm font-medium text-gray-900">No exams found</h3>
            <p class="mt-1 text-sm text-gray-500">Get started by creating a new exam.</p>
            <div class="mt-6">
                <a href="<?php echo e(route('admin.exams.create')); ?>" 
                   class="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">
                    ➕ Create New Exam
                </a>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\exam\exam-system\resources\views/admin/exams/index.blade.php ENDPATH**/ ?>