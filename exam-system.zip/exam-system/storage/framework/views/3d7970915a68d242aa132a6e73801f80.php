<?php $__env->startSection('title', 'Question Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8 max-w-5xl">
    <!-- Header -->
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 class="text-3xl font-bold text-gray-900">Question Details</h1>
            <p class="text-gray-600 mt-1">Question ID: #<?php echo e($question->id); ?></p>
        </div>
        <div class="flex gap-3">
            <a href="<?php echo e(route('admin.questions.edit', $question)); ?>" 
               class="bg-yellow-500 hover:bg-yellow-600 text-white px-6 py-2 rounded-lg font-semibold transition">
                ✏️ Edit
            </a>
            <a href="<?php echo e(route('admin.questions.index')); ?>" 
               class="bg-gray-300 hover:bg-gray-400 text-gray-800 px-6 py-2 rounded-lg font-semibold transition">
                ← Back
            </a>
        </div>
    </div>

    <!-- Question Metadata -->
    <div class="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 class="text-xl font-bold text-gray-900 mb-4">📋 Question Information</h2>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <!-- Category -->
            <div>
                <label class="block text-sm font-medium text-gray-600 mb-1">Exam Category</label>
                <?php if($question->examCategory): ?>
                    <span class="inline-block px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-semibold">
                        <?php echo e($question->examCategory->name); ?>

                    </span>
                <?php else: ?>
                    <span class="inline-block px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-sm font-semibold">
                        No Category
                    </span>
                <?php endif; ?>
            </div>

            <!-- Subject -->
            <div>
                <label class="block text-sm font-medium text-gray-600 mb-1">Subject</label>
                <span class="inline-block px-3 py-1 bg-indigo-100 text-indigo-800 rounded-full text-sm font-semibold">
                    <?php echo e($question->subject->name ?? 'N/A'); ?>

                </span>
            </div>

            <!-- Chapter -->
            <div>
                <label class="block text-sm font-medium text-gray-600 mb-1">Chapter</label>
                <?php if($question->chapter): ?>
                    <span class="inline-block px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm font-semibold">
                        <?php echo e($question->chapter->name); ?>

                    </span>
                <?php else: ?>
                    <span class="text-gray-500 text-sm">Not Assigned</span>
                <?php endif; ?>
            </div>

            <!-- Topic -->
            <div>
                <label class="block text-sm font-medium text-gray-600 mb-1">Topic</label>
                <?php if($question->topic): ?>
                    <span class="inline-block px-3 py-1 bg-pink-100 text-pink-800 rounded-full text-sm font-semibold">
                        <?php echo e($question->topic->name); ?>

                    </span>
                <?php else: ?>
                    <span class="text-gray-500 text-sm">Not Assigned</span>
                <?php endif; ?>
            </div>

            <!-- Difficulty -->
            <div>
                <label class="block text-sm font-medium text-gray-600 mb-1">Difficulty</label>
                <?php if($question->difficulty): ?>
                    <?php if($question->difficulty->level == 1): ?>
                        <span class="inline-block px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-semibold">
                            <?php echo e($question->difficulty->name); ?>

                        </span>
                    <?php elseif($question->difficulty->level == 2): ?>
                        <span class="inline-block px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full text-sm font-semibold">
                            <?php echo e($question->difficulty->name); ?>

                        </span>
                    <?php else: ?>
                        <span class="inline-block px-3 py-1 bg-red-100 text-red-800 rounded-full text-sm font-semibold">
                            <?php echo e($question->difficulty->name); ?>

                        </span>
                    <?php endif; ?>
                <?php else: ?>
                    <span class="text-gray-500 text-sm">N/A</span>
                <?php endif; ?>
            </div>

            <!-- Marks -->
            <div>
                <label class="block text-sm font-medium text-gray-600 mb-1">Marks</label>
                <div class="flex gap-4">
                    <span class="text-green-600 font-bold text-lg">+<?php echo e($question->marks); ?></span>
                    <?php if($question->negative_marks > 0): ?>
                        <span class="text-red-600 font-bold text-lg">-<?php echo e($question->negative_marks); ?></span>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Status -->
            <div>
                <label class="block text-sm font-medium text-gray-600 mb-1">Status</label>
                <?php if($question->is_active): ?>
                    <span class="inline-block px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-semibold">
                        ✓ Active
                    </span>
                <?php else: ?>
                    <span class="inline-block px-3 py-1 bg-red-100 text-red-800 rounded-full text-sm font-semibold">
                        ✗ Inactive
                    </span>
                <?php endif; ?>
            </div>

            <!-- Created By -->
            <div>
                <label class="block text-sm font-medium text-gray-600 mb-1">Created By</label>
                <span class="text-gray-800 text-sm">
                    <?php echo e($question->creator->name ?? 'Unknown'); ?>

                </span>
            </div>
        </div>
    </div>

    <!-- Question Content -->
    <div class="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 class="text-xl font-bold text-gray-900 mb-4">❓ Question</h2>
        
        <div class="prose max-w-none mb-4">
            <?php echo $question->question_text; ?>

        </div>

        <?php if($question->question_image): ?>
            <div class="mt-4">
                <img src="<?php echo e(asset('storage/' . $question->question_image)); ?>" 
                     alt="Question Image" 
                     class="max-w-full h-auto rounded-lg border border-gray-300">
            </div>
        <?php endif; ?>
    </div>

    <!-- Answer Options -->
    <div class="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 class="text-xl font-bold text-gray-900 mb-4">📝 Answer Options</h2>
        
        <div class="space-y-3">
            <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="p-4 rounded-lg border-2 <?php echo e($option->is_correct ? 'border-green-500 bg-green-50' : 'border-gray-300 bg-gray-50'); ?>">
                    <div class="flex items-start justify-between">
                        <div class="flex-1">
                            <div class="flex items-center gap-3 mb-2">
                                <span class="inline-flex items-center justify-center w-8 h-8 rounded-full 
                                             <?php echo e($option->is_correct ? 'bg-green-500 text-white' : 'bg-gray-400 text-white'); ?> 
                                             font-bold">
                                    <?php echo e($option->option_key); ?>

                                </span>
                                <?php if($option->is_correct): ?>
                                    <span class="px-3 py-1 bg-green-500 text-white text-xs font-bold rounded-full">
                                        ✓ CORRECT ANSWER
                                    </span>
                                <?php endif; ?>
                            </div>
                            
                            <div class="prose max-w-none ml-11">
                                <?php echo $option->option_text; ?>

                            </div>

                            <?php if($option->option_image): ?>
                                <div class="mt-3 ml-11">
                                    <img src="<?php echo e(asset('storage/' . $option->option_image)); ?>" 
                                         alt="Option <?php echo e($option->option_key); ?>" 
                                         class="max-w-xs h-auto rounded-lg border border-gray-300">
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Correct Answer Summary -->
        <div class="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
            <p class="text-sm font-medium text-green-800">
                <strong>Correct Answer(s):</strong>
                <?php $__currentLoopData = $question->options->where('is_correct', true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $correct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="inline-block px-2 py-1 bg-green-500 text-white rounded-full text-xs font-bold ml-2">
                        <?php echo e($correct->option_key); ?>

                    </span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>
        </div>
    </div>

    <!-- Explanation -->
    <?php if($question->explanation): ?>
        <div class="bg-white rounded-lg shadow-md p-6 mb-6">
            <h2 class="text-xl font-bold text-gray-900 mb-4">💡 Explanation</h2>
            
            <div class="prose max-w-none">
                <?php echo $question->explanation; ?>

            </div>

            <?php if($question->explanation_image): ?>
                <div class="mt-4">
                    <img src="<?php echo e(asset('storage/' . $question->explanation_image)); ?>" 
                         alt="Explanation Image" 
                         class="max-w-full h-auto rounded-lg border border-gray-300">
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <!-- Timestamps -->
    <div class="bg-white rounded-lg shadow-md p-6">
        <h2 class="text-xl font-bold text-gray-900 mb-4">⏰ Timestamps</h2>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
                <span class="text-gray-600 font-medium">Created At:</span>
                <span class="text-gray-800 ml-2"><?php echo e($question->created_at->format('M d, Y h:i A')); ?></span>
            </div>
            <div>
                <span class="text-gray-600 font-medium">Last Updated:</span>
                <span class="text-gray-800 ml-2"><?php echo e($question->updated_at->format('M d, Y h:i A')); ?></span>
            </div>
        </div>
    </div>

    <!-- Action Buttons -->
    <div class="mt-6 flex gap-4">
        <a href="<?php echo e(route('admin.questions.edit', $question)); ?>" 
           class="bg-yellow-500 hover:bg-yellow-600 text-white px-8 py-3 rounded-lg font-semibold transition shadow-md">
            ✏️ Edit Question
        </a>
        
        <form action="<?php echo e(route('admin.questions.destroy', $question)); ?>" 
              method="POST" 
              onsubmit="return confirm('Are you sure you want to delete this question? This action cannot be undone.');">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" 
                    class="bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-lg font-semibold transition shadow-md">
                🗑️ Delete Question
            </button>
        </form>
        
        <a href="<?php echo e(route('admin.questions.index')); ?>" 
           class="bg-gray-300 hover:bg-gray-400 text-gray-800 px-8 py-3 rounded-lg font-semibold transition shadow-md">
            ← Back to Questions
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\exam\exam-system\resources\views/admin/questions/show.blade.php ENDPATH**/ ?>